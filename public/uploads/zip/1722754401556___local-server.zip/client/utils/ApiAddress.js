export const ipv4Address = '192.168.0.76'; 
export const logUrl = 'http://192.168.0.76:9000/data';
export const apiUrl = 'http://192.168.0.76:9000/';