import React from "react";
interface FilesComponentType {}

const FilesComponent: React.FC<FilesComponentType> = () => {
    return <div>FilesComponent</div>;
};

export default FilesComponent;
