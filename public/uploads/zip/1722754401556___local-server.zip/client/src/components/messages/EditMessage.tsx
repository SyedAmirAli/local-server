import React from "react";
interface EditMessageType {}

const EditMessage: React.FC<EditMessageType> = () => {
    return <div>EditMessage</div>;
};

export default EditMessage;
